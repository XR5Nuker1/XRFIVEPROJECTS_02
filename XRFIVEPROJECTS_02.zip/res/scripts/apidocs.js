function update(mi, mw){
  var x1 = document.getElementById(mi)
var sys = x1.style.display
var x2 = document.getElementById(mw)
if(sys=="none"){
  x1.style.display = "block"
 x2.style.height = "370px"
 }else{
 x1.style.display = "none"
 x2.style.height = "40px"
}
  
  
 
}
